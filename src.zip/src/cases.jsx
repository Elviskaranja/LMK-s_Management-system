import { useMemo, useState } from "react";
import { Search, Plus, X, Eye, Pencil, Trash2, BriefcaseBusiness, CalendarDays, CircleCheck, Clock3, ChevronDown } from "lucide-react";
import "./cases.css";

const starterCases = [
  { id: 1, number: "LMK-2026-001", title: "Mwangi v. Horizon Properties", client: "David Mwangi", advocate: "Grace Wanjiku", type: "Civil Litigation", court: "Milimani Law Courts", filed: "2026-08-12", hearing: "2026-11-12", status: "In Progress", priority: "High", notes: "Property ownership dispute. Review supporting documents before the next hearing." },
  { id: 2, number: "LMK-2026-002", title: "Estate of Peter Otieno", client: "Mary Otieno", advocate: "James Kamau", type: "Succession", court: "High Court - Nairobi", filed: "2026-07-21", hearing: "2026-11-18", status: "Pending", priority: "Medium", notes: "Awaiting the next court direction." },
  { id: 3, number: "LMK-2026-003", title: "Kilonzo v. Eastline Ltd", client: "Anne Kilonzo", advocate: "Grace Wanjiku", type: "Employment", court: "Employment and Labour Relations Court", filed: "2026-05-09", hearing: "", status: "Under Review", priority: "Low", notes: "Review client documents and confirm the next procedural step." },
  { id: 4, number: "LMK-2025-014", title: "Njoroge Contract Dispute", client: "Brian Njoroge", advocate: "James Kamau", type: "Commercial", court: "Milimani Commercial Courts", filed: "2025-12-03", hearing: "", status: "Closed", priority: "Low", notes: "Matter concluded." }
];
const blank = { number: "", title: "", client: "", advocate: "", type: "Civil Litigation", court: "", filed: "", hearing: "", status: "Pending", priority: "Medium", notes: "" };
const statuses = ["Pending", "In Progress", "Under Review", "Closed"];
const types = ["Civil Litigation", "Criminal", "Succession", "Employment", "Commercial", "Family", "Other"];
const dateLabel = value => value ? new Date(value + "T00:00:00").toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }) : "Not scheduled";

export default function Cases() {
  const [cases, setCases] = useState(starterCases);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("All cases");
  const [modal, setModal] = useState("");
  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState(blank);
  const [error, setError] = useState("");

  const shown = useMemo(() => cases.filter(c => {
    const searchable = [c.number, c.title, c.client, c.advocate, c.type].join(" ").toLowerCase();
    return searchable.includes(query.toLowerCase()) && (filter === "All cases" || c.status === filter);
  }), [cases, query, filter]);
  const upcoming = cases.filter(c => {
    if (!c.hearing || c.status === "Closed") return false;
    const days = (new Date(c.hearing + "T00:00:00") - new Date(new Date().toDateString())) / 86400000;
    return days >= 0 && days <= 30;
  }).length;

  function addCase() {
    setSelected(null);
    setForm({ ...blank, number: `LMK-${new Date().getFullYear()}-${String(cases.length + 1).padStart(3, "0")}` });
    setError(""); setModal("form");
  }
  function editCase(c) { setSelected(c); setForm({ ...c }); setError(""); setModal("form"); }
  function change(e) { setForm(f => ({ ...f, [e.target.name]: e.target.value })); }
  function save(e) {
    e.preventDefault();
    if (!form.number.trim() || !form.title.trim() || !form.client.trim() || !form.advocate.trim()) {
      setError("Complete the case number, case title, client, and assigned advocate."); return;
    }
    if (cases.some(c => c.number.toLowerCase() === form.number.trim().toLowerCase() && c.id !== selected?.id)) {
      setError("That case number already exists. Enter a unique number."); return;
    }
    if (selected) setCases(list => list.map(c => c.id === selected.id ? { ...form, id: selected.id } : c));
    else setCases(list => [{ ...form, id: Date.now() }, ...list]);
    setModal(""); setSelected(null); setError("");
  }
  function removeCase(c) {
    if (window.confirm(`Delete "${c.title}" (${c.number})? This cannot be undone.`)) {
      setCases(list => list.filter(item => item.id !== c.id));
      if (selected?.id === c.id) { setSelected(null); setModal(""); }
    }
  }

  return <main className="cases-page">
    <header className="cases-header">
      <div><div className="cases-eyebrow">CASE MANAGEMENT</div><h1>Cases</h1><p>Manage case records, track progress, and keep upcoming hearings in view.</p></div>
      <button className="cases-primary" onClick={addCase}><Plus size={18}/> Add New Case</button>
    </header>

    <section className="cases-stats">
      <article className="cases-stat"><span className="cases-stat-icon"><BriefcaseBusiness size={20}/></span><div><small>Total cases</small><strong>{cases.length}</strong><em>All registered matters</em></div></article>
      <article className="cases-stat"><span className="cases-stat-icon green"><CircleCheck size={20}/></span><div><small>In progress</small><strong>{cases.filter(c => c.status === "In Progress").length}</strong><em>Currently being handled</em></div></article>
      <article className="cases-stat"><span className="cases-stat-icon amber"><Clock3 size={20}/></span><div><small>Pending / review</small><strong>{cases.filter(c => c.status === "Pending" || c.status === "Under Review").length}</strong><em>Awaiting the next step</em></div></article>
      <article className="cases-stat"><span className="cases-stat-icon blue"><CalendarDays size={20}/></span><div><small>Hearings soon</small><strong>{upcoming}</strong><em>Within the next 30 days</em></div></article>
    </section>

    <section className="cases-panel">
      <div className="cases-panel-heading"><div><h2>Case register</h2><p>Search and manage the firm's case records.</p></div><span className="cases-count">{shown.length} {shown.length === 1 ? "case" : "cases"}</span></div>
      <div className="cases-toolbar">
        <label className="cases-search"><Search size={18}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search case, client, advocate..." aria-label="Search cases"/>{query && <button onClick={() => setQuery("")} aria-label="Clear search"><X size={15}/></button>}</label>
        <label className="cases-filter"><span>Status</span><span className="cases-select"><select value={filter} onChange={e => setFilter(e.target.value)}>{["All cases", ...statuses].map(s => <option key={s}>{s}</option>)}</select><ChevronDown size={15}/></span></label>
      </div>
      <div className="cases-table-scroll"><table className="cases-table"><thead><tr><th>Case details</th><th>Client / advocate</th><th>Next hearing</th><th>Status</th><th>Priority</th><th>Actions</th></tr></thead>
        <tbody>{shown.map(c => <tr key={c.id}>
          <td><strong className="cases-title">{c.title}</strong><div className="cases-sub">{c.number} <span>·</span> {c.type}</div></td>
          <td><strong className="cases-person">{c.client}</strong><div className="cases-sub">Adv. {c.advocate}</div></td>
          <td><strong className="cases-date">{dateLabel(c.hearing)}</strong>{c.hearing && <div className="cases-sub">Court hearing</div>}</td>
          <td><span className={`cases-status status-${c.status.toLowerCase().replaceAll(" ", "-")}`}>{c.status}</span></td>
          <td><span className={`cases-priority priority-${c.priority.toLowerCase()}`}><i/>{c.priority}</span></td>
          <td><div className="cases-actions"><button title="View case" aria-label={`View ${c.number}`} onClick={() => {setSelected(c);setModal("view");}}><Eye size={16}/></button><button title="Edit case" aria-label={`Edit ${c.number}`} onClick={() => editCase(c)}><Pencil size={16}/></button><button title="Delete case" aria-label={`Delete ${c.number}`} onClick={() => removeCase(c)}><Trash2 size={16}/></button></div></td>
        </tr>)}
        {!shown.length && <tr><td colSpan="6"><div className="cases-empty"><strong>No cases found</strong><p>Try another search or change the status filter.</p><button onClick={() => {setQuery("");setFilter("All cases");}}>Clear filters</button></div></td></tr>}
        </tbody></table></div>
      <footer className="cases-footnote">Demo records are held in temporary page state and reset when the page is refreshed.</footer>
    </section>

    {modal === "form" && <div className="cases-overlay" onMouseDown={e => {if(e.target === e.currentTarget)setModal("");}}><section className="cases-modal" role="dialog" aria-modal="true" aria-labelledby="case-form-title">
      <div className="cases-modal-head"><div><span className="cases-eyebrow">CASE RECORD</span><h2 id="case-form-title">{selected ? "Edit case" : "Register a new case"}</h2><p>Fields marked * are required.</p></div><button className="cases-close" onClick={() => setModal("")} aria-label="Close"><X size={20}/></button></div>
      {error && <div className="cases-error" role="alert">{error}</div>}
      <form onSubmit={save}><div className="cases-form-grid">
        <label>Case number *<input name="number" value={form.number} onChange={change} placeholder="e.g. LMK-2026-005"/></label>
        <label>Case title *<input name="title" value={form.title} onChange={change} placeholder="e.g. Smith v. ABC Ltd"/></label>
        <label>Client name *<input name="client" value={form.client} onChange={change} placeholder="Client's full name"/></label>
        <label>Assigned advocate *<input name="advocate" value={form.advocate} onChange={change} placeholder="Advocate's full name"/></label>
        <label>Case type<select name="type" value={form.type} onChange={change}>{types.map(t => <option key={t}>{t}</option>)}</select></label>
        <label>Court / location<input name="court" value={form.court} onChange={change} placeholder="Court or tribunal"/></label>
        <label>Filing date<input type="date" name="filed" value={form.filed} onChange={change}/></label>
        <label>Next hearing date<input type="date" name="hearing" value={form.hearing} onChange={change}/></label>
        <label>Case status<select name="status" value={form.status} onChange={change}>{statuses.map(s => <option key={s}>{s}</option>)}</select></label>
        <label>Priority<select name="priority" value={form.priority} onChange={change}>{["Low","Medium","High"].map(p => <option key={p}>{p}</option>)}</select></label>
        <label className="cases-wide">Notes / next steps<textarea name="notes" value={form.notes} onChange={change} rows="3" placeholder="Optional notes for this matter"/></label>
      </div><div className="cases-modal-footer"><button type="button" className="cases-secondary" onClick={() => setModal("")}>Cancel</button><button className="cases-primary" type="submit">{selected ? "Save changes" : "Save case"}</button></div></form>
    </section></div>}

    {modal === "view" && selected && <div className="cases-overlay" onMouseDown={e => {if(e.target === e.currentTarget)setModal("");}}><section className="cases-modal cases-view-modal" role="dialog" aria-modal="true" aria-labelledby="case-view-title">
      <div className="cases-modal-head"><div><span className="cases-eyebrow">{selected.number}</span><h2 id="case-view-title">{selected.title}</h2><p>Case overview and key details</p></div><button className="cases-close" onClick={() => setModal("")} aria-label="Close"><X size={20}/></button></div>
      <div className="cases-view-badges"><span className={`cases-status status-${selected.status.toLowerCase().replaceAll(" ", "-")}`}>{selected.status}</span><span className={`cases-priority priority-${selected.priority.toLowerCase()}`}><i/>{selected.priority} priority</span></div>
      <div className="cases-detail-grid">{[["Client",selected.client],["Assigned advocate",selected.advocate],["Case type",selected.type],["Court / location",selected.court || "Not specified"],["Filing date",dateLabel(selected.filed)],["Next hearing",dateLabel(selected.hearing)]].map(([label,value]) => <div key={label}><span>{label}</span><strong>{value || "—"}</strong></div>)}</div>
      <div className="cases-notes"><span>Notes / next steps</span><p>{selected.notes || "No notes have been added."}</p></div>
      <div className="cases-modal-footer"><button className="cases-secondary" onClick={() => setModal("")}>Close</button><button className="cases-primary" onClick={() => editCase(selected)}><Pencil size={16}/> Edit case</button></div>
    </section></div>}
  </main>;
}
