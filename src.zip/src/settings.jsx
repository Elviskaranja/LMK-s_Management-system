
import { useState } from "react";
import {
  UserRound,
  ShieldCheck,
  Bell,
  SlidersHorizontal,
  Save,
  Eye,
  EyeOff,
  Check,
} from "lucide-react";
import "./settings.css";

export default function Settings() {
  const [activeTab, setActiveTab] = useState("Profile");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [saved, setSaved] = useState(false);

  const [profile, setProfile] = useState({
    fullName: "System Administrator",
    email: "admin@lmkadvocates.co.ke",
    phone: "+254 700 000 000",
    role: "Administrator",
  });

  const [passwords, setPasswords] = useState({
    current: "",
    newPassword: "",
    confirm: "",
  });

  const [notifications, setNotifications] = useState({
    appointments: true,
    caseUpdates: true,
    paymentUpdates: true,
    systemAlerts: true,
  });

  const [preferences, setPreferences] = useState({
    language: "English",
    dateFormat: "DD/MM/YYYY",
    currency: "KES",
  });

  const handleSave = (event) => {
    event.preventDefault();
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const tabs = [
    { name: "Profile", icon: UserRound },
    { name: "Security", icon: ShieldCheck },
    { name: "Notifications", icon: Bell },
    { name: "Preferences", icon: SlidersHorizontal },
  ];

  return (
    <div className="settings-page">
      <div className="settings-heading">
        <div>
          <p className="settings-eyebrow">SYSTEM CONFIGURATION</p>
          <h1>Settings</h1>
          <p>Manage your account and system preferences.</p>
        </div>
      </div>

      <div className="settings-layout">
        <aside className="settings-sidebar">
          <div className="settings-sidebar-title">ACCOUNT SETTINGS</div>

          {tabs.map(({ name, icon: Icon }) => (
            <button
              key={name}
              className={`settings-tab ${activeTab === name ? "active" : ""}`}
              onClick={() => setActiveTab(name)}
            >
              <Icon size={18} />
              <span>{name}</span>
            </button>
          ))}
        </aside>

        <section className="settings-content">
          {activeTab === "Profile" && (
            <form onSubmit={handleSave}>
              <div className="settings-section-heading">
                <div>
                  <h2>Profile Information</h2>
                  <p>Update the personal information associated with your account.</p>
                </div>
                <UserRound size={23} />
              </div>

              <div className="settings-profile">
                <div className="settings-avatar">SA</div>
                <div>
                  <h3>{profile.fullName}</h3>
                  <p>{profile.role}</p>
                </div>
              </div>

              <div className="settings-form-grid">
                <div className="settings-field">
                  <label>Full Name</label>
                  <input
                    value={profile.fullName}
                    onChange={(e) => setProfile({ ...profile, fullName: e.target.value })}
                    required
                  />
                </div>

                <div className="settings-field">
                  <label>Email Address</label>
                  <input
                    type="email"
                    value={profile.email}
                    onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                    required
                  />
                </div>

                <div className="settings-field">
                  <label>Phone Number</label>
                  <input
                    value={profile.phone}
                    onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                  />
                </div>

                <div className="settings-field">
                  <label>Role</label>
                  <input value={profile.role} disabled />
                </div>
              </div>

              <div className="settings-save-row">
                <button type="submit" className="settings-save-btn">
                  <Save size={16} /> Save Changes
                </button>
              </div>
            </form>
          )}

          {activeTab === "Security" && (
            <form onSubmit={(event) => {
              event.preventDefault();
              if (passwords.newPassword !== passwords.confirm) {
                alert("The new passwords do not match.");
                return;
              }
              alert("Password form validated. Connect backend authentication to update your password.");
              setPasswords({ current: "", newPassword: "", confirm: "" });
            }}>
              <div className="settings-section-heading">
                <div>
                  <h2>Security Settings</h2>
                  <p>Manage your account password and security.</p>
                </div>
                <ShieldCheck size={23} />
              </div>

              <div className="settings-security-note">
                <ShieldCheck size={19} />
                <span>Keep your account secure by using a strong, unique password.</span>
              </div>

              {[
                { label: "Current Password", key: "current", visible: showPassword, toggle: () => setShowPassword(!showPassword) },
                { label: "New Password", key: "newPassword", visible: showPassword, toggle: () => setShowPassword(!showPassword) },
                { label: "Confirm New Password", key: "confirm", visible: showConfirmPassword, toggle: () => setShowConfirmPassword(!showConfirmPassword) },
              ].map((field) => (
                <div className="settings-field settings-password-field" key={field.key}>
                  <label>{field.label}</label>
                  <div className="settings-password-input">
                    <input
                      type={field.visible ? "text" : "password"}
                      value={passwords[field.key]}
                      onChange={(e) => setPasswords({ ...passwords, [field.key]: e.target.value })}
                      required
                      minLength={field.key === "current" ? undefined : 8}
                    />
                    <button type="button" onClick={field.toggle} aria-label="Toggle password visibility">
                      {field.visible ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </div>
              ))}

              <div className="settings-save-row">
                <button type="submit" className="settings-save-btn">
                  <ShieldCheck size={16} /> Update Password
                </button>
              </div>
            </form>
          )}

          {activeTab === "Notifications" && (
            <div>
              <div className="settings-section-heading">
                <div>
                  <h2>Notification Preferences</h2>
                  <p>Choose which system updates you want to receive.</p>
                </div>
                <Bell size={23} />
              </div>

              <div className="settings-notification-list">
                {[
                  { key: "appointments", title: "Appointment Reminders", description: "Receive updates about upcoming client appointments." },
                  { key: "caseUpdates", title: "Case Updates", description: "Get notified when case records are updated." },
                  { key: "paymentUpdates", title: "Payment Notifications", description: "Receive updates about recorded client payments." },
                  { key: "systemAlerts", title: "System Alerts", description: "Receive important system and account alerts." },
                ].map((item) => (
                  <div className="settings-notification-item" key={item.key}>
                    <div>
                      <h3>{item.title}</h3>
                      <p>{item.description}</p>
                    </div>
                    <label className="settings-switch">
                      <input
                        type="checkbox"
                        checked={notifications[item.key]}
                        onChange={(e) => setNotifications({
                          ...notifications,
                          [item.key]: e.target.checked,
                        })}
                      />
                      <span className="settings-switch-slider" />
                    </label>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === "Preferences" && (
            <form onSubmit={handleSave}>
              <div className="settings-section-heading">
                <div>
                  <h2>System Preferences</h2>
                  <p>Configure how information is displayed in the system.</p>
                </div>
                <SlidersHorizontal size={23} />
              </div>

              <div className="settings-form-grid">
                <div className="settings-field">
                  <label>Language</label>
                  <select
                    value={preferences.language}
                    onChange={(e) => setPreferences({ ...preferences, language: e.target.value })}
                  >
                    <option>English</option>
                    <option>Kiswahili</option>
                  </select>
                </div>

                <div className="settings-field">
                  <label>Date Format</label>
                  <select
                    value={preferences.dateFormat}
                    onChange={(e) => setPreferences({ ...preferences, dateFormat: e.target.value })}
                  >
                    <option>DD/MM/YYYY</option>
                    <option>MM/DD/YYYY</option>
                    <option>YYYY-MM-DD</option>
                  </select>
                </div>

                <div className="settings-field">
                  <label>Currency</label>
                  <select
                    value={preferences.currency}
                    onChange={(e) => setPreferences({ ...preferences, currency: e.target.value })}
                  >
                    <option value="KES">Kenyan Shilling (KES)</option>
                    <option value="USD">US Dollar (USD)</option>
                  </select>
                </div>
              </div>

              <div className="settings-save-row">
                <button type="submit" className="settings-save-btn">
                  <Save size={16} /> Save Preferences
                </button>
              </div>
            </form>
          )}

          {saved && (
            <div className="settings-success">
              <Check size={17} /> Changes saved in this session.
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
