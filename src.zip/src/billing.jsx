
import { useMemo, useState } from "react";
import {
  Search,
  Plus,
  FileText,
  CircleDollarSign,
  CheckCircle,
  Clock,
  X,
  CreditCard,
  Download,
} from "lucide-react";
import "./billing.css";

const initialInvoices = [
  {
    id: "INV-001",
    client: "James Mwangi",
    caseRef: "CASE-001",
    description: "Legal consultation",
    amount: 25000,
    date: "2026-10-12",
    dueDate: "2026-11-12",
    status: "Paid",
  },
  {
    id: "INV-002",
    client: "Sarah Wanjiku",
    caseRef: "CASE-002",
    description: "Court representation",
    amount: 45000,
    date: "2026-10-18",
    dueDate: "2026-11-08",
    status: "Pending",
  },
  {
    id: "INV-003",
    client: "David Otieno",
    caseRef: "CASE-003",
    description: "Document preparation",
    amount: 15000,
    date: "2026-09-20",
    dueDate: "2026-10-20",
    status: "Overdue",
  },
  {
    id: "INV-004",
    client: "Grace Njeri",
    caseRef: "CASE-004",
    description: "Legal advisory",
    amount: 30000,
    date: "2026-10-25",
    dueDate: "2026-11-25",
    status: "Paid",
  },
];

const formatCurrency = (amount) =>
  new Intl.NumberFormat("en-KE", {
    style: "currency",
    currency: "KES",
    maximumFractionDigits: 0,
  }).format(amount);

export default function Billing() {
  const [invoices, setInvoices] = useState(initialInvoices);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({
    client: "",
    caseRef: "",
    description: "",
    amount: "",
    date: "",
    dueDate: "",
  });

  const totals = useMemo(() => ({
    billed: invoices.reduce((sum, item) => sum + item.amount, 0),
    paid: invoices
      .filter((item) => item.status === "Paid")
      .reduce((sum, item) => sum + item.amount, 0),
    outstanding: invoices
      .filter((item) => item.status !== "Paid")
      .reduce((sum, item) => sum + item.amount, 0),
    overdue: invoices
      .filter((item) => item.status === "Overdue")
      .reduce((sum, item) => sum + item.amount, 0),
  }), [invoices]);

  const filteredInvoices = invoices.filter((item) => {
    const matchesSearch =
      `${item.id} ${item.client} ${item.caseRef} ${item.description}`
        .toLowerCase()
        .includes(search.toLowerCase());

    const matchesFilter = filter === "All" || item.status === filter;
    return matchesSearch && matchesFilter;
  });

  const addInvoice = (event) => {
    event.preventDefault();

    const newInvoice = {
      ...form,
      id: `INV-${String(invoices.length + 1).padStart(3, "0")}`,
      amount: Number(form.amount),
      status: "Pending",
    };

    setInvoices((previous) => [...previous, newInvoice]);
    setForm({
      client: "",
      caseRef: "",
      description: "",
      amount: "",
      date: "",
      dueDate: "",
    });
    setShowModal(false);
  };

  const markAsPaid = (id) => {
    setInvoices((previous) =>
      previous.map((item) =>
        item.id === id ? { ...item, status: "Paid" } : item
      )
    );
  };

  return (
    <div className="billing-page">
      <div className="billing-heading">
        <div>
          <p className="billing-eyebrow">FINANCIAL MANAGEMENT</p>
          <h1>Billing & Payments</h1>
          <p>Manage client invoices and keep track of payments.</p>
        </div>

        <button className="billing-primary-btn" onClick={() => setShowModal(true)}>
          <Plus size={18} /> Create Invoice
        </button>
      </div>

      <div className="billing-stats">
        <div className="billing-stat-card">
          <div className="billing-stat-icon"><FileText /></div>
          <span>Total Billed</span>
          <h2>{formatCurrency(totals.billed)}</h2>
          <small>All recorded invoices</small>
        </div>

        <div className="billing-stat-card">
          <div className="billing-stat-icon"><CheckCircle /></div>
          <span>Total Paid</span>
          <h2>{formatCurrency(totals.paid)}</h2>
          <small>Successfully recorded payments</small>
        </div>

        <div className="billing-stat-card">
          <div className="billing-stat-icon"><CircleDollarSign /></div>
          <span>Outstanding</span>
          <h2>{formatCurrency(totals.outstanding)}</h2>
          <small>Payments yet to be received</small>
        </div>

        <div className="billing-stat-card">
          <div className="billing-stat-icon"><Clock /></div>
          <span>Overdue</span>
          <h2>{formatCurrency(totals.overdue)}</h2>
          <small>Invoices past their due date</small>
        </div>
      </div>

      <section className="billing-table-panel">
        <div className="billing-table-heading">
          <div>
            <h2>Invoice Records</h2>
            <p>View and manage invoices issued to clients.</p>
          </div>
        </div>

        <div className="billing-toolbar">
          <div className="billing-search">
            <Search size={18} />
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search invoices, clients or case..."
            />
          </div>

          <select value={filter} onChange={(event) => setFilter(event.target.value)}>
            <option value="All">All statuses</option>
            <option value="Paid">Paid</option>
            <option value="Pending">Pending</option>
            <option value="Overdue">Overdue</option>
          </select>
        </div>

        <div className="billing-table-scroll">
          <table className="billing-table">
            <thead>
              <tr>
                <th>Invoice</th>
                <th>Client</th>
                <th>Case Reference</th>
                <th>Description</th>
                <th>Amount</th>
                <th>Due Date</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredInvoices.map((invoice) => (
                <tr key={invoice.id}>
                  <td className="billing-invoice-id">{invoice.id}</td>
                  <td>{invoice.client}</td>
                  <td>{invoice.caseRef}</td>
                  <td>{invoice.description}</td>
                  <td className="billing-amount">{formatCurrency(invoice.amount)}</td>
                  <td>{invoice.dueDate}</td>
                  <td>
                    <span className={`billing-status ${invoice.status.toLowerCase()}`}>
                      {invoice.status}
                    </span>
                  </td>
                  <td>
                    {invoice.status !== "Paid" ? (
                      <button
                        className="billing-action-btn"
                        onClick={() => markAsPaid(invoice.id)}
                      >
                        Mark paid
                      </button>
                    ) : (
                      <span className="billing-completed">Recorded</span>
                    )}
                  </td>
                </tr>
              ))}

              {filteredInvoices.length === 0 && (
                <tr>
                  <td colSpan="8" className="billing-empty">
                    No invoices match your search.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {showModal && (
        <div className="billing-modal-overlay">
          <form className="billing-modal" onSubmit={addInvoice}>
            <div className="billing-modal-heading">
              <div>
                <h2>Create New Invoice</h2>
                <p>Enter the invoice details below.</p>
              </div>
              <button type="button" className="billing-close-btn" onClick={() => setShowModal(false)}>
                <X />
              </button>
            </div>

            <label>Client Name</label>
            <input
              required
              value={form.client}
              onChange={(e) => setForm({ ...form, client: e.target.value })}
              placeholder="Enter client name"
            />

            <label>Case Reference</label>
            <input
              required
              value={form.caseRef}
              onChange={(e) => setForm({ ...form, caseRef: e.target.value })}
              placeholder="e.g. CASE-005"
            />

            <label>Description</label>
            <input
              required
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              placeholder="Enter service description"
            />

            <label>Amount (KES)</label>
            <input
              required
              type="number"
              min="1"
              value={form.amount}
              onChange={(e) => setForm({ ...form, amount: e.target.value })}
              placeholder="Enter amount"
            />

            <div className="billing-date-fields">
              <div>
                <label>Invoice Date</label>
                <input
                  required
                  type="date"
                  value={form.date}
                  onChange={(e) => setForm({ ...form, date: e.target.value })}
                />
              </div>
              <div>
                <label>Due Date</label>
                <input
                  required
                  type="date"
                  min={form.date || undefined}
                  value={form.dueDate}
                  onChange={(e) => setForm({ ...form, dueDate: e.target.value })}
                />
              </div>
            </div>

            <div className="billing-modal-actions">
              <button type="button" className="billing-cancel-btn" onClick={() => setShowModal(false)}>
                Cancel
              </button>
              <button type="submit" className="billing-primary-btn">
                Create Invoice
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
