import { useMemo, useState } from "react";
import {
  Search, Plus, X, Eye, Pencil, Trash2,
  CalendarDays, Clock3, CircleCheck, CircleX
} from "lucide-react";
import "./appointments.css";

const initialAppointments = [
  {
    id: 1,
    client: "James Mwangi",
    caseTitle: "Land Dispute",
    advocate: "Adv. Kamau",
    date: "2026-11-05",
    time: "09:00",
    status: "Upcoming",
  },
  {
    id: 2,
    client: "Mary Wanjiku",
    caseTitle: "Divorce Proceedings",
    advocate: "Adv. Njeri",
    date: "2026-10-28",
    time: "11:00",
    status: "Completed",
  },
  {
    id: 3,
    client: "Peter Otieno",
    caseTitle: "Employment Dispute",
    advocate: "Adv. Kamau",
    date: "2026-11-08",
    time: "14:00",
    status: "Upcoming",
  },
];

export  default function Appointments() {
  const [appointments, setAppointments] = useState(initialAppointments);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");
  const [showModal, setShowModal] = useState(false);
  const [selected, setSelected] = useState(null);
  const [mode, setMode] = useState("add");

  const emptyForm = {
    client: "",
    caseTitle: "",
    advocate: "",
    date: "",
    time: "",
    status: "Upcoming",
  };

  const [form, setForm] = useState(emptyForm);

  const filteredAppointments = useMemo(() => {
    return appointments.filter((appointment) => {
      const matchesSearch = [
        appointment.client,
        appointment.caseTitle,
        appointment.advocate,
      ].some((value) =>
        value.toLowerCase().includes(search.toLowerCase())
      );

      const matchesFilter =
        filter === "All" || appointment.status === filter;

      return matchesSearch && matchesFilter;
    });
  }, [appointments, search, filter]);

  const openAdd = () => {
    setForm(emptyForm);
    setMode("add");
    setSelected(null);
    setShowModal(true);
  };

  const openEdit = (appointment) => {
    setForm({ ...appointment });
    setMode("edit");
    setSelected(appointment);
    setShowModal(true);
  };

  const openView = (appointment) => {
    setSelected(appointment);
    setMode("view");
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setSelected(null);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (mode === "edit") {
      setAppointments((current) =>
        current.map((item) =>
          item.id === selected.id ? { ...form, id: selected.id } : item
        )
      );
    } else {
      setAppointments((current) => [
        ...current,
        { ...form, id: Date.now() },
      ]);
    }

    closeModal();
  };

  const deleteAppointment = (id) => {
    if (window.confirm("Are you sure you want to delete this appointment?")) {
      setAppointments((current) =>
        current.filter((appointment) => appointment.id !== id)
      );
    }
  };

  const updateField = (event) => {
    setForm({ ...form, [event.target.name]: event.target.value });
  };

  return (
    <main className="appointments-page">
      <div className="appointments-heading">
        <div>
          <p className="appointments-eyebrow">WORKSPACE</p>
          <h1>Appointments</h1>
          <p className="appointments-subtitle">
            Schedule and manage client appointments.
          </p>
        </div>

        <button className="appointments-primary-btn" onClick={openAdd}>
          <Plus size={18} /> New Appointment
        </button>
      </div>

      <div className="appointments-stats">
        <div className="appointment-stat-card">
          <span className="appointment-stat-icon"><CalendarDays /></span>
          <div>
            <p>Total Appointments</p>
            <h2>{appointments.length}</h2>
          </div>
        </div>

        <div className="appointment-stat-card">
          <span className="appointment-stat-icon"><Clock3 /></span>
          <div>
            <p>Upcoming</p>
            <h2>{appointments.filter(a => a.status === "Upcoming").length}</h2>
          </div>
        </div>

        <div className="appointment-stat-card">
          <span className="appointment-stat-icon"><CircleCheck /></span>
          <div>
            <p>Completed</p>
            <h2>{appointments.filter(a => a.status === "Completed").length}</h2>
          </div>
        </div>

        <div className="appointment-stat-card">
          <span className="appointment-stat-icon"><CircleX /></span>
          <div>
            <p>Cancelled</p>
            <h2>{appointments.filter(a => a.status === "Cancelled").length}</h2>
          </div>
        </div>
      </div>

      <section className="appointments-panel">
        <div className="appointments-panel-heading">
          <div>
            <h2>Appointment Register</h2>
            <p>View and manage scheduled appointments.</p>
          </div>
        </div>

        <div className="appointments-toolbar">
          <div className="appointments-search">
            <Search size={18} />
            <input
              type="text"
              placeholder="Search client, case or advocate..."
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
          </div>

          <select value={filter} onChange={(event) => setFilter(event.target.value)}>
            <option value="All">All Statuses</option>
            <option value="Upcoming">Upcoming</option>
            <option value="Completed">Completed</option>
            <option value="Cancelled">Cancelled</option>
          </select>
        </div>

        <div className="appointments-table-wrap">
          <table className="appointments-table">
            <thead>
              <tr>
                <th>CLIENT</th>
                <th>CASE</th>
                <th>ADVOCATE</th>
                <th>DATE & TIME</th>
                <th>STATUS</th>
                <th>ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              {filteredAppointments.map((appointment) => (
                <tr key={appointment.id}>
                  <td>{appointment.client}</td>
                  <td>{appointment.caseTitle}</td>
                  <td>{appointment.advocate}</td>
                  <td>
                    {appointment.date}
                    <small>{appointment.time}</small>
                  </td>
                  <td>
                    <span className={`appointment-status ${appointment.status.toLowerCase()}`}>
                      {appointment.status}
                    </span>
                  </td>
                  <td>
                    <div className="appointment-actions">
                      <button title="View" onClick={() => openView(appointment)}><Eye size={16} /></button>
                      <button title="Edit" onClick={() => openEdit(appointment)}><Pencil size={16} /></button>
                      <button title="Delete" onClick={() => deleteAppointment(appointment.id)}><Trash2 size={16} /></button>
                    </div>
                  </td>
                </tr>
              ))}

              {filteredAppointments.length === 0 && (
                <tr>
                  <td colSpan="6" className="appointments-empty">
                    No appointments found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {showModal && (
        <div className="appointments-modal-overlay" onClick={closeModal}>
          <div className="appointments-modal" onClick={(event) => event.stopPropagation()}>
            <div className="appointments-modal-heading">
              <div>
                <h2>
                  {mode === "add" ? "New Appointment" : mode === "edit" ? "Edit Appointment" : "Appointment Details"}
                </h2>
                <p>Appointment information</p>
              </div>
              <button onClick={closeModal}><X /></button>
            </div>

            {mode === "view" ? (
              <div className="appointment-details">
                <p><strong>Client:</strong> {selected.client}</p>
                <p><strong>Case:</strong> {selected.caseTitle}</p>
                <p><strong>Advocate:</strong> {selected.advocate}</p>
                <p><strong>Date:</strong> {selected.date}</p>
                <p><strong>Time:</strong> {selected.time}</p>
                <p><strong>Status:</strong> {selected.status}</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit}>
                <label>Client Name
                  <input name="client" value={form.client} onChange={updateField} required />
                </label>

                <label>Case
                  <input name="caseTitle" value={form.caseTitle} onChange={updateField} required />
                </label>

                <label>Advocate
                  <input name="advocate" value={form.advocate} onChange={updateField} required />
                </label>

                <div className="appointments-form-row">
                  <label>Date
                    <input type="date" name="date" value={form.date} onChange={updateField} required />
                  </label>
                  <label>Time
                    <input type="time" name="time" value={form.time} onChange={updateField} required />
                  </label>
                </div>

                <label>Status
                  <select name="status" value={form.status} onChange={updateField}>
                    <option>Upcoming</option>
                    <option>Completed</option>
                    <option>Cancelled</option>
                  </select>
                </label>

                <div className="appointments-modal-actions">
                  <button type="button" className="appointments-cancel-btn" onClick={closeModal}>Cancel</button>
                  <button type="submit" className="appointments-primary-btn">
                    {mode === "edit" ? "Save Changes" : "Add Appointment"}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </main>
  );
}