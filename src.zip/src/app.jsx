import Clients from "./clients.jsx";
import Login from "./login.jsx";
import Cases from "./cases.jsx";
import Appointments from "./appointments.jsx";
import Documents from "./documents.jsx";
import Billing from "./billing.jsx";
import Settings from "./settings.jsx";
import { useState } from "react";
import {
  LayoutDashboard,
  Users,
  BriefcaseBusiness,
  CalendarDays,
  Files,
  CreditCard,
  Settings as SettingsIcon,
  Search,
  Bell,
  Plus,
  ArrowUpRight,
  Clock3,
  Gavel,
  Menu,
  X,
  ChevronDown,
  MoreHorizontal,
  Scale,
} from "lucide-react";
import "./app.css";

const navigation = [
  { label: "Dashboard", icon: LayoutDashboard },
  { label: "Clients", icon: Users },
  { label: "Cases", icon: BriefcaseBusiness },
  { label: "Appointments", icon: CalendarDays },
  { label: "Documents", icon: Files },
  { label: "Billing", icon: CreditCard },
];

const cases = [
  {
    id: "HC-2026-014",
    name: "Anderson vs. Whitmore",
    client: "Olivia Anderson",
    type: "Civil Litigation",
    date: "18 Oct 2026",
    status: "In Progress",
  },
  {
    id: "HC-2026-011",
    name: "Estate of James Miller",
    client: "Daniel Miller",
    type: "Estate Planning",
    date: "20 Oct 2026",
    status: "Under Review",
  },
  {
    id: "HC-2026-008",
    name: "Carter Property Dispute",
    client: "Michael Carter",
    type: "Property Law",
    date: "22 Oct 2026",
    status: "In Progress",
  },
  {
    id: "HC-2026-005",
    name: "Thompson Employment Claim",
    client: "Sarah Thompson",
    type: "Employment Law",
    date: "24 Oct 2026",
    status: "Pending",
  },
];

const appointments = [
  {
    day: "15",
    month: "OCT",
    time: "09:30 AM",
    title: "Client Consultation",
    person: "Olivia Anderson",
    type: "Consultation",
  },
  {
    day: "15",
    month: "OCT",
    time: "11:00 AM",
    title: "Case Review Meeting",
    person: "Daniel Miller",
    type: "Case review",
  },
  {
    day: "16",
    month: "OCT",
    time: "02:00 PM",
    title: "Court Preparation",
    person: "Michael Carter",
    type: "Preparation",
  },
];

const stats = [
  {
    label: "Active Cases",
    value: "24",
    change: "+12.5%",
    positive: true,
    icon: BriefcaseBusiness,
    note: "vs. last month",
  },
  {
    label: "Total Clients",
    value: "86",
    change: "+8.2%",
    positive: true,
    icon: Users,
    note: "vs. last month",
  },
  {
    label: "Upcoming Hearings",
    value: "07",
    change: "Next 7 days",
    positive: null,
    icon: Gavel,
    note: "across all cases",
  },
  {
    label: "Outstanding Fees",
    value: "KSh 248K",
    change: "Needs attention",
    positive: false,
    icon: CreditCard,
    note: "unpaid invoices",
  },
];

function App() {
  const [activePage, setActivePage] = useState("Dashboard");
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [showNotifications, setShowNotifications] = useState(false);


  // Set to true to bypass login and open straight into the dashboard
  const [isAuthenticated, setIsAuthenticated] = useState(true);

  const filteredCases = cases.filter((item) =>
    `${item.name} ${item.client} ${item.id}`
      .toLowerCase()
      .includes(searchTerm.toLowerCase())
  );

  function choosePage(page) {
    setActivePage(page);
    setMenuOpen(false);
  }

 if (!isAuthenticated) {
    return <Login />;
  }


  return (
    <div className="app-shell">
      <aside className={`sidebar ${menuOpen ? "sidebar-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark">
            <Scale size={25} strokeWidth={1.5} />
          </div>
          <div className="brand-copy">
            <span className="brand-name">LMK <span>Advocates</span></span>
            <span className="brand-subtitle">ATTORNEYS AT LAW</span>
          </div>
          <button
            className="icon-button mobile-close"
            onClick={() => setMenuOpen(false)}
            aria-label="Close menu"
          >
            <X size={19} />
          </button>
        </div>

        <div className="workspace-label">WORKSPACE</div>
        <nav className="navigation">
          {navigation.map(({ label, icon: Icon }) => (
            <button
              key={label}
              className={`nav-item ${activePage === label ? "active" : ""}`}
              onClick={() => choosePage(label)}
            >
              <Icon size={19} strokeWidth={1.7} />
              <span>{label}</span>
              {label === "Cases" && <span className="nav-count">24</span>}
            </button>
          ))}
        </nav>

        <div className="sidebar-divider" />
        <div className="workspace-label">PREFERENCES</div>
        <button
          className={`nav-item ${activePage === "Settings" ? "active" : ""}`}
          onClick={() => choosePage("Settings")}
        >
          <SettingsIcon size={19} strokeWidth={1.7} />
          <span>Settings</span>
        </button>

        <div className="sidebar-spacer" />

        <div className="sidebar-help">
          <div className="help-icon"><Scale size={18} /></div>
          <p>Need assistance?</p>
          <span>Contact your system administrator.</span>
          <button onClick={() => window.alert("Please contact your system administrator.")}>
            Get support <ArrowUpRight size={14} />
          </button>
        </div>

        <div className="sidebar-profile">
          <div className="avatar avatar-gold">AK</div>
          <div className="profile-info">
            <strong>Alexandra Keane</strong>
            <span>Managing Partner</span>
          </div>
          <button className="icon-button" aria-label="Profile options">
            <MoreHorizontal size={19} />
          </button>
        </div>
      </aside>

      {menuOpen && (
        <button
          className="mobile-overlay"
          aria-label="Close navigation"
          onClick={() => setMenuOpen(false)}
        />
      )}

      <main className="main-area">
        <header className="topbar">
          <div className="topbar-left">
            <button
              className="icon-button mobile-menu"
              onClick={() => setMenuOpen(true)}
              aria-label="Open menu"
            >
              <Menu size={21} />
            </button>
            <div className="breadcrumb">
              <span>Workspace</span>
              <span className="breadcrumb-slash">/</span>
              <strong>{activePage}</strong>
            </div>
          </div>

          <div className="topbar-actions">
            <label className="search-box">
              <Search size={17} />
              <input
                value={searchTerm}
                onChange={(event) => setSearchTerm(event.target.value)}
                placeholder="Search cases..."
                aria-label="Search cases"
              />
              <kbd>⌘ K</kbd>
            </label>
            <div className="notification-wrap">
              <button
                className="icon-button notification-button"
                aria-label="Notifications"
                onClick={() => setShowNotifications(!showNotifications)}
              >
                <Bell size={19} />
                <span className="notification-dot" />
              </button>
              {showNotifications && (
                <div className="notification-popover">
                  <strong>Notifications</strong>
                  <p>You have 2 items to review.</p>
                  <p className="notification-detail">Upcoming client consultation · Today</p>
                  <p className="notification-detail">Outstanding invoice requires follow-up</p>
                </div>
              )}
            </div>
            <div className="topbar-divider" />
            <button className="topbar-user" onClick={() => choosePage("Settings")}>
              <div className="avatar avatar-dark">AK</div>
              <ChevronDown size={15} />
            </button>
          </div>
        </header>

        <div className="page-content">
          {activePage === "Clients" ? (
            <Clients />
          ) 
          : activePage === "Cases" ? (
            <Cases />
          ) 
      : activePage === "Appointments" ? (
            <Appointments />
        )
           : activePage === "Documents" ? (
            <Documents />
          )
          : activePage === "Billing" ? (
            <Billing />
          )
          : activePage === "Settings" ? (
            <Settings />
          ) 
          : activePage === "Dashboard" ? (
            <>
            
              <section className="welcome-row">
                <div>
                  <div className="eyebrow"><span className="eyebrow-line" /> THURSDAY, OCTOBER 15, 2026</div>
                  <h1>Good evening, Alexandra<span>.</span></h1>
                  <p className="welcome-subtitle">
                    Here&apos;s what&apos;s happening across your firm today.
                  </p>
                </div>
                <button
                  className="primary-button"
                  onClick={() => choosePage("Cases")}
                >
                  <Plus size={17} /> New case
                </button>
              </section>

              <section className="stats-grid" aria-label="Firm overview">
                {stats.map(({ label, value, change, positive, icon: Icon, note }) => (
                  <article className="stat-card" key={label}>
                    <div className="stat-card-top">
                      <div className="stat-icon"><Icon size={19} strokeWidth={1.7} /></div>
                      <button className="icon-button stat-more" aria-label={`More about ${label}`}>
                        <MoreHorizontal size={19} />
                      </button>
                    </div>
                    <p className="stat-label">{label}</p>
                    <div className="stat-value">{value}</div>
                    <div className="stat-foot">
                      <span className={`stat-change ${positive === true ? "positive" : positive === false ? "attention" : "neutral"}`}>
                        {positive === true && <ArrowUpRight size={13} />}
                        {positive === false && <Clock3 size={13} />}
                        {change}
                      </span>
                      <span className="stat-note">{note}</span>
                    </div>
                  </article>
                ))}
              </section>

              <section className="content-grid">
                <article className="panel cases-panel">
                  <div className="panel-heading">
                    <div>
                      <h2>Recent cases</h2>
                      <p>A snapshot of your firm&apos;s ongoing matters.</p>
                    </div>
                    <button className="text-button" onClick={() => choosePage("Cases")}>
                      View all <ArrowUpRight size={15} />
                    </button>
                  </div>

                  <div className="table-scroll">
                    <table className="cases-table">
                      <thead>
                        <tr>
                          <th>CASE / CLIENT</th>
                          <th>CASE TYPE</th>
                          <th>NEXT DATE</th>
                          <th>STATUS</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredCases.length > 0 ? filteredCases.map((item) => (
                          <tr key={item.id}>
                            <td>
                              <div className="case-name">{item.name}</div>
                              <div className="case-id">{item.id} · {item.client}</div>
                            </td>
                            <td><span className="case-type">{item.type}</span></td>
                            <td><span className="case-date">{item.date}</span></td>
                            <td>
                              <span className={`status-pill ${item.status.toLowerCase().replace(" ", "-")}`}>
                                <span className="status-dot" />{item.status}
                              </span>
                            </td>
                          </tr>
                        )) : (
                          <tr>
                            <td colSpan="4" className="empty-state">
                              No cases match &quot;{searchTerm}&quot;.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                  <div className="panel-footer">
                    <span>Showing {filteredCases.length} of {cases.length} sample cases</span>
                    <button className="footer-link" onClick={() => choosePage("Cases")}>
                      Manage cases <ArrowUpRight size={14} />
                    </button>
                  </div>
                </article>

                <article className="panel appointments-panel">
                  <div className="panel-heading">
                    <div>
                      <h2>Upcoming schedule</h2>
                      <p>Your next appointments and meetings.</p>
                    </div>
                    <button
                      className="icon-button"
                      aria-label="View appointments"
                      onClick={() => choosePage("Appointments")}
                    >
                      <ArrowUpRight size={17} />
                    </button>
                  </div>
                  <div className="appointments-list">
                    {appointments.map((appointment, index) => (
                      <div className="appointment" key={`${appointment.title}-${index}`}>
                        <div className="appointment-date">
                          <span>{appointment.month}</span>
                          <strong>{appointment.day}</strong>
                        </div>
                        <div className="appointment-details">
                          <strong>{appointment.title}</strong>
                          <span>{appointment.person}</span>
                          <div className="appointment-time">
                            <Clock3 size={13} /> {appointment.time}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  <button className="schedule-button" onClick={() => choosePage("Appointments")}>
                    <CalendarDays size={16} /> Open calendar
                  </button>
                </article>
              </section>

              <section className="bottom-grid">
                <article className="firm-note">
                  <div className="firm-note-mark"><Scale size={23} /></div>
                  <div>
                    <span className="note-overline">LMK Advocates · FIRM NOTE</span>
                    <h3>Excellence in every matter.</h3>
                    <p>Stay organized, keep your clients informed, and give every case the attention it deserves.</p>
                  </div>
                </article>
                <article className="quick-actions panel">
                  <div>
                    <h2>Quick actions</h2>
                    <p>Get straight to work.</p>
                  </div>
                  <div className="quick-action-buttons">
                    <button onClick={() => choosePage("Clients")}><Users size={16} /> Add client</button>
                    <button onClick={() => choosePage("Appointments")}><CalendarDays size={16} /> Schedule</button>
                    <button onClick={() => choosePage("Documents")}><Files size={16} /> Documents</button>
                  </div>
                </article>
              </section>

              <footer className="page-footer">
                <span>© 2026 LMK Advocates Attorneys at Law</span>
                <span><span className="footer-status-dot" /> All systems operational</span>
              </footer>
            </>
          ) : (
            <section className="placeholder-page panel">
              <div className="placeholder-icon">
                {(() => {
                  const ItemIcon = navigation.find((item) => item.label === activePage)?.icon || SettingsIcon;
                  return <ItemIcon size={28} />;
                })()}
              </div>
              <span className="eyebrow">LMK Advocates</span>
              <h1>{activePage}</h1>
              <p>
                The {activePage.toLowerCase()} workspace is ready for us to build next.
                This is a demonstration interface; records shown on the dashboard are sample data.
              </p>
              <button className="primary-button" onClick={() => choosePage("Dashboard")}>
                <LayoutDashboard size={16} /> Back to dashboard
              </button>
            </section>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;